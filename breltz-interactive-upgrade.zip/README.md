# Breltz interactive upgrade
Copy assets/ into the existing repository. Insert these two tags immediately after the existing closing </script> and before </html> in index.html:

<link rel="stylesheet" href="assets/experience.css">
<script src="assets/experience.js"></script>

This is an additive enhancement for the inspected single-file dashboard. It requires the existing globals rows, totals, sum, money, renderOrders and existing element IDs. No dependencies or API keys.

Test manually: open overview, click all six metrics, navigate to filtered orders, run refund and duplicate/invalid events, rerun consistency checks, inspect department cards, navigate the tour and test keyboard/mobile. JavaScript syntax checked with Node; browser and deployment not verified. Data and AI remain synthetic/rule-based. No new warehouse-level data is invented.
